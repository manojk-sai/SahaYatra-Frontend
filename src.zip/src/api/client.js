const API_BASE = "http://localhost:8080";

async function request(method, path, body, token) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || data.error || `Error ${res.status}`);
  return data;
}
function extractTrip(payload) {
  const isTrip = candidate => (
    candidate
    && typeof candidate === "object"
    && candidate.id
    && (
      candidate.title !== undefined
      || candidate.status !== undefined
      || Array.isArray(candidate.stops)
      || Array.isArray(candidate.members)
    )
  );

  const candidates = [payload, payload?.trip, payload?.updatedTrip, payload?.data?.trip, payload?.data];
  return candidates.find(isTrip) || null;
}
export const api = {
  // ── Phase 1: Auth ────────────────────────────────────
  async login(username, password) {
    return request("POST", "/auth/login", { username, password });
  },
  async register(formData) {
    return request("POST", "/auth/register", formData);
  },
  async getCurrentUser(token) {
    return request("GET", "/users/me", null, token);
  },
  async updateProfile(profileData, token) {
    return request("PUT", "/users/me", profileData, token);
  },

  // ── Phase 2: Trips ───────────────────────────────────
  async createTrip(data, token) {
    return request("POST", "/trips", data, token);
  },
  async getMyTrips(token) {
    return request("GET", "/trips/my", null, token);
  },
  async getPublicTrips() {
    return request("GET", "/trips/public", null, null);
  },
  async getTripById(tripId, token) {
    const data = await request("GET", `/trips/${tripId}`, null, token);
    return extractTrip(data) || data;  },
  async updateTrip(tripId, data, token) {
    return request("PATCH", `/trips/${tripId}`, data, token);
  },
  async advanceTripStatus(tripId, token) {
    const data = await request("POST", `/trips/${tripId}/advance`, null, token);
    return extractTrip(data) || data;
  },
  async lockTrip(tripId, token) {
    return request("POST", `/trips/${tripId}/lock`, null, token);
  },

  // ── Phase 2: Stops ───────────────────────────────────
  async addStop(tripId, data, token) {
    const response = await request("POST", `/trips/${tripId}/stops`, data, token);
    return extractTrip(response) || response;  },
  async removeStop(tripId, stopId, token) {
    const response = await request("DELETE", `/trips/${tripId}/stops/${stopId}`, null, token);
    return extractTrip(response) || response;  },
  async reorderStops(tripId, orderedIds, token) {
    const response = await request("PATCH", `/trips/${tripId}/stops/reorder`, orderedIds, token);
    return extractTrip(response) || response;
  },

  // ── Phase 2: Members ─────────────────────────────────
  async inviteMember(tripId, userId, role, token) {
    const response = await request("POST", `/trips/${tripId}/invite`, { userId, role }, token);
    return extractTrip(response) || response;
  },
  async acceptInvite(inviteToken, token) {
    return request("POST", `/trips/join?token=${inviteToken}`, null, token);
  },
  async leaveTrip(tripId, token) {
    return request("POST", `/trips/${tripId}/leave`, null, token);
  },
  async transferOwnership(tripId, newOrganizerId, token) {
    return request("POST", `/trips/${tripId}/transfer`, { newOrganizerId }, token);
  },

  // ── Phase 3: Voting ─────────────────────────────────
  async voteStop(tripId, stopId, voteType, token) {
    const response = await request("POST", `/trips/${tripId}/stops/${stopId}/vote`, { voteType }, token);
    return extractTrip(response) || response
  },
  async getStopVotes(tripId, stopId, token) {
    return request("GET", `/trips/${tripId}/stops/${stopId}/votes`, null, token);
  },
};
